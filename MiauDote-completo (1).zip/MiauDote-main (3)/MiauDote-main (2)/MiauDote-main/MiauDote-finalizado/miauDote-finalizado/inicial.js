
 //  carrossel

 document.addEventListener('DOMContentLoaded', function() {
    // Configurações do carrossel
    const carousel = document.getElementById('carousel');
    const dotsContainer = document.getElementById('carouselDots');
    const prevBtn = document.getElementById('prevBtn');
    const nextBtn = document.getElementById('nextBtn');
    
    // Dados dos parceiros (simulados)
    const partners = [
        { id: 1, name: 'Parceiro 1', color: '#ffcdd2' },
        { id: 2, name: 'Parceiro 2', color: '#f8bbd0' },
        { id: 3, name: 'Parceiro 3', color: '#e1bee7' },
        { id: 4, name: 'Parceiro 4', color: '#d1c4e9' },
        { id: 5, name: 'Parceiro 5', color: '#c5cae9' },
        { id: 6, name: 'Parceiro 6', color: '#bbdefb' },
        { id: 7, name: 'Parceiro 7', color: '#b3e5fc' },
        { id: 8, name: 'Parceiro 8', color: '#b2ebf2' },
        { id: 9, name: 'Parceiro 9', color: '#b2dfdb' }
    ];
    
    
    let currentIndex = 0;
    let itemsPerView = getItemsPerView();
    let totalSlides = Math.ceil(partners.length / itemsPerView);
    let autoPlayInterval;
    let isDragging = false;
    let startPos = 0;
    let currentTranslate = 0;
    let prevTranslate = 0;
    
    // Inicializar o carrossel
    function initCarousel() {
        
        createCarouselItems();
        
        createDots();
        
       
        updateCarousel();
       
        startAutoPlay();
        
    
        addEventListeners();
    }
    
    // Criar itens do carrossel
    function createCarouselItems() {
        carousel.innerHTML = '';
        
        partners.forEach((partner, index) => {
            const item = document.createElement('div');
            item.className = 'carousel-item';
            
            const circle = document.createElement('div');
            circle.className = 'partner-circle';
            circle.style.backgroundColor = partner.color;
            circle.innerHTML = `<span>${partner.id}</span>`;
            
            const name = document.createElement('p');
            name.className = 'partner-name';
            name.textContent = partner.name;
            
            item.appendChild(circle);
            item.appendChild(name);
            carousel.appendChild(item);
            
          
            if (Math.random() > 0.7) {
                circle.classList.add('pulse');
            }
        });
    }
    
  
    function createDots() {
        dotsContainer.innerHTML = '';
        
        for (let i = 0; i < totalSlides; i++) {
            const dot = document.createElement('div');
            dot.className = 'dot';
            if (i === 0) dot.classList.add('active');
            
            dot.addEventListener('click', () => {
                goToSlide(i);
            });
            
            dotsContainer.appendChild(dot);
        }
    }
    
    // Obter número de itens visíveis com base no tamanho da tela
    function getItemsPerView() {
        if (window.innerWidth < 768) {
            return 1;
        } else if (window.innerWidth < 992) {
            return 2;
        } else {
            return 3;
        }
    }
    
 
    function updateCarousel() {
        const itemWidth = carousel.querySelector('.carousel-item').offsetWidth;
        const translateX = -currentIndex * itemWidth * itemsPerView;
        
        carousel.style.transform = `translateX(${translateX}px)`;
        
      
        const dots = dotsContainer.querySelectorAll('.dot');
        dots.forEach((dot, index) => {
            dot.classList.toggle('active', index === currentIndex);
        });
    }
    
  
    function goToSlide(index) {
        currentIndex = Math.max(0, Math.min(index, totalSlides - 1));
        updateCarousel();
        resetAutoPlay();
    }
  
    function nextSlide() {
        if (currentIndex < totalSlides - 1) {
            currentIndex++;
        } else {
        
            currentIndex = 0;
        }
        
        updateCarousel();
        resetAutoPlay();
    }
    
    
    function prevSlide() {
        if (currentIndex > 0) {
            currentIndex--;
        } else {
          
            currentIndex = totalSlides - 1;
        }
        
        updateCarousel();
        resetAutoPlay();
    }
  
    function startAutoPlay() {
        autoPlayInterval = setInterval(() => {
            nextSlide();
        }, 5000);
    }
    
    
    function resetAutoPlay() {
        clearInterval(autoPlayInterval);
        startAutoPlay();
    }
    

    function addEventListeners() {
      
        prevBtn.addEventListener('click', prevSlide);
        nextBtn.addEventListener('click', nextSlide);
        
    
        document.addEventListener('keydown', (e) => {
            if (e.key === 'ArrowLeft') prevSlide();
            if (e.key === 'ArrowRight') nextSlide();
        });
        
      
        carousel.addEventListener('touchstart', touchStart);
        carousel.addEventListener('touchmove', touchMove);
        carousel.addEventListener('touchend', touchEnd);
        
        carousel.addEventListener('mouseenter', () => {
            clearInterval(autoPlayInterval);
        });
        
        carousel.addEventListener('mouseleave', () => {
            startAutoPlay();
        });
        
     
        window.addEventListener('resize', handleResize);
    }
    
   
    function handleResize() {
        const newItemsPerView = getItemsPerView();
        
        if (newItemsPerView !== itemsPerView) {
            itemsPerView = newItemsPerView;
            totalSlides = Math.ceil(partners.length / itemsPerView);
            
          
            if (currentIndex >= totalSlides) {
                currentIndex = totalSlides - 1;
            }
            
         
            createDots();
            
         
            updateCarousel();
        }
    }
    
 
    function touchStart(event) {
        isDragging = true;
        startPos = event.touches[0].clientX;
        carousel.style.transition = 'none';
    }
    
    function touchMove(event) {
        if (!isDragging) return;
        
        const currentPosition = event.touches[0].clientX;
        const diff = currentPosition - startPos;
        
     
        const itemWidth = carousel.querySelector('.carousel-item').offsetWidth;
        const baseTranslate = -currentIndex * itemWidth * itemsPerView;
        currentTranslate = baseTranslate + diff;

        if (currentIndex === 0 && diff > 0) {
            currentTranslate = baseTranslate + (diff * 0.3);
        } else if (currentIndex === totalSlides - 1 && diff < 0) {
            currentTranslate = baseTranslate + (diff * 0.3);
        }
        
        carousel.style.transform = `translateX(${currentTranslate}px)`;
    }
    
    function touchEnd(event) {
        isDragging = false;
        carousel.style.transition = 'transform 0.5s ease';
        
        const itemWidth = carousel.querySelector('.carousel-item').offsetWidth;
        const movedBy = startPos - event.changedTouches[0].clientX;
        
       
        if (movedBy > 100 && currentIndex < totalSlides - 1) {
            nextSlide();
        } else if (movedBy < -100 && currentIndex > 0) {
            prevSlide();
        } else {
        
            updateCarousel();
        }
        
        resetAutoPlay();
    }
  
    function addRandomHighlight() {
        const circles = document.querySelectorAll('.partner-circle');
        const randomIndex = Math.floor(Math.random() * circles.length);
        
        circles.forEach(circle => {
            circle.classList.remove('pulse');
        });
        
        circles[randomIndex].classList.add('pulse');
    }
    
   
    initCarousel();
    

    setInterval(addRandomHighlight, 3000);
  });
    
  
    const setupFilters = () => {
      const filterButton = document.querySelector(".btn-filter")
      const clearFilterButton = document.querySelector(".btn-clear-filter")
      const catCards = document.querySelectorAll(".cat-card")
  
      if (filterButton) {
        filterButton.addEventListener("click", () => {
          const selectedIdades = getSelectedFilters("idade")
          const selectedSexos = getSelectedFilters("sexo")
          const selectedCores = getSelectedFilters("cor")
          const selectedSaude = getSelectedFilters("saude")
  
          const anyFilterSelected =
            selectedIdades.length > 0 || selectedSexos.length > 0 || selectedCores.length > 0 || selectedSaude.length > 0
  
          if (!anyFilterSelected) {
            alert("Nenhum filtro selecionado!")
            return
          }
  
          catCards.forEach((card) => {
            const idade = card.getAttribute("data-idade")
            const sexo = card.getAttribute("data-sexo")
            const cor = card.getAttribute("data-cor")
            const saude = card.getAttribute("data-saude")
  
            const matchesIdade = selectedIdades.length === 0 || selectedIdades.includes(idade)
            const matchesSexo = selectedSexos.length === 0 || selectedSexos.includes(sexo)
            const matchesCor = selectedCores.length === 0 || selectedCores.includes(cor)
  
    
            const matchesSaude =
              selectedSaude.length === 0 || selectedSaude.every((item) => saude && saude.includes(item))
  
            if (matchesIdade && matchesSexo && matchesCor && matchesSaude) {
              card.classList.remove("hidden")
            } else {
              card.classList.add("hidden")
            }
          })
  
        
          updateCatCounter()
        })
      }
  
  
      if (clearFilterButton) {
        clearFilterButton.addEventListener("click", () => {
        
          document.querySelectorAll('.filter-option input[type="checkbox"]').forEach((checkbox) => {
            checkbox.checked = false
          })
  
          
          catCards.forEach((card) => {
            card.classList.remove("hidden")
          })
  
       
          updateCatCounter()
        })
      }
    }
  
    const getSelectedFilters = (name) => {
      const checkboxes = document.querySelectorAll(`.filter-option input[name="${name}"]:checked`)
      return Array.from(checkboxes).map((checkbox) => checkbox.value)
    }
  
  
    const updateCatCounter = () => {
      const visibleCats = document.querySelectorAll(".cat-card:not(.hidden)").length
      const pageTitle = document.querySelector(".page-title")
  
      if (pageTitle) {
        pageTitle.textContent = `${visibleCats} Gatinhos Encontrados`
      }
    }
  
  
    const setupAdoptButtons = () => {
      const adoptButtons = document.querySelectorAll(".btn-adopt")
      adoptButtons.forEach((button) => {
        button.addEventListener("click", function () {
          const catName = this.closest(".cat-info").querySelector("h3").textContent
          alert(`Você iniciou o processo de adoção para ${catName}! Em breve entraremos em contato.`)
        })
      })
    }
  
  // Configurar modal de adoção
  const setupAdoptionModal = () => {
    const modalOverlay = document.getElementById('modalOverlay');
    const modalClose = document.getElementById('modalClose');
    const cancelBtn = document.getElementById('cancelBtn');
    const adoptionForm = document.getElementById('adoptionForm');
    const phoneInput = document.getElementById('adopterPhone');

    // Abrir modal ao clicar em qualquer botão "Me adote"
    document.addEventListener('click', (e) => {
      if (e.target.classList.contains('btn-adopt')) {
        currentCatName = e.target.getAttribute('data-cat-name') || 'este gatinho';
        openModal();
      }
    });

    // Fechar modal
    const closeModal = () => {
      modalOverlay.classList.remove('active');
      document.body.style.overflow = 'auto';
      adoptionForm.reset();
    };

    const openModal = () => {
      modalOverlay.classList.add('active');
      document.body.style.overflow = 'hidden';
    };

    modalClose.addEventListener('click', closeModal);
    cancelBtn.addEventListener('click', closeModal);

    // Fechar modal ao clicar no overlay
    modalOverlay.addEventListener('click', (e) => {
      if (e.target === modalOverlay) {
        closeModal();
      }
    });

    // Fechar modal com ESC
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && modalOverlay.classList.contains('active')) {
        closeModal();
      }
    });

    // Máscara para telefone
    phoneInput.addEventListener('input', (e) => {
      let value = e.target.value.replace(/\D/g, '');
      
      if (value.length > 0) {
        if (value.length <= 2) {
          value = `(${value}`;
        } else if (value.length <= 7) {
          value = `(${value.substring(0, 2)}) ${value.substring(2)}`;
        } else if (value.length <= 11) {
          value = `(${value.substring(0, 2)}) ${value.substring(2, 7)}-${value.substring(7)}`;
        } else {
          value = `(${value.substring(0, 2)}) ${value.substring(2, 7)}-${value.substring(7, 11)}`;
        }
      }
      
      e.target.value = value;
    });

    // Envio do formulário
    adoptionForm.addEventListener('submit', (e) => {
      e.preventDefault();
      
      const formData = {
        nome: document.getElementById('adopterName').value.trim(),
        email: document.getElementById('adopterEmail').value.trim(),
        telefone: phoneInput.value.trim(),
        mensagem: document.getElementById('adopterMessage').value.trim(),
        gato: currentCatName
      };

      // Validações
      if (!formData.nome) {
        showNotification('Por favor, informe seu nome completo.', 'error');
        return;
      }

      if (!formData.email || !isValidEmail(formData.email)) {
        showNotification('Por favor, informe um email válido.', 'error');
        return;
      }

      if (!formData.telefone || formData.telefone.length < 14) {
        showNotification('Por favor, informe um telefone válido.', 'error');
        return;
      }

      // Simular envio
      const submitBtn = document.querySelector('.btn-submit');
      const originalText = submitBtn.textContent;
      
      submitBtn.innerHTML = 'Enviando...';
      submitBtn.disabled = true;

      setTimeout(() => {
        showNotification(`Solicitação de adoção para ${currentCatName} enviada com sucesso! Entraremos em contato em breve.`, 'success');
        closeModal();
        
        submitBtn.innerHTML = originalText;
        submitBtn.disabled = false;
        
        // Aqui você enviaria os dados para o servidor
        console.log('Dados da adoção:', formData);
      }, 2000);
    });
  };

  // Função para validar email
  const isValidEmail = (email) => {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
  };

  // Função para mostrar notificações
  const showNotification = (message, type = 'info') => {
    // Remover notificação existente
    const existingNotification = document.querySelector('.notification');
    if (existingNotification) {
      existingNotification.remove();
    }

    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.textContent = message;
    
    // Estilos da notificação
    notification.style.cssText = `
      position: fixed;
      top: 20px;
      right: 20px;
      padding: 15px 20px;
      border-radius: 8px;
      color: white;
      font-weight: 500;
      z-index: 10000;
      transform: translateX(100%);
      transition: transform 0.3s ease;
      max-width: 350px;
      word-wrap: break-word;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
    `;
    
    if (type === 'success') {
      notification.style.backgroundColor = '#4CAF50';
    } else if (type === 'error') {
      notification.style.backgroundColor = '#f44336';
    } else if (type === 'warning') {
      notification.style.backgroundColor = '#ff9800';
    } else {
      notification.style.backgroundColor = '#2196F3';
    }
    
    document.body.appendChild(notification);
    
    // Animar entrada
    setTimeout(() => {
      notification.style.transform = 'translateX(0)';
    }, 100);
    
    // Remover após 5 segundos
    setTimeout(() => {
      notification.style.transform = 'translateX(100%)';
      setTimeout(() => {
        if (notification.parentNode) {
          notification.parentNode.removeChild(notification);
        }
      }, 300);
    }, 5000);
  };

  // Inicializar todas as funcionalidades
  setupFilters();
  setupAdoptionModal();


  

 //  footer

    document.addEventListener('DOMContentLoaded', function() {
  
        const footerLinks = document.querySelectorAll('.footer-links a');
        
        footerLinks.forEach(link => {
            link.addEventListener('mouseenter', function() {
                this.style.transition = 'all 0.3s ease';
            });
        });
        
       
       
        const socialIcons = document.querySelectorAll('.social-icon');
        
        socialIcons.forEach(icon => {
            icon.addEventListener('mouseenter', function() {
                this.style.transform = 'translateY(-3px)';
            });
            
            icon.addEventListener('mouseleave', function() {
                this.style.transform = 'translateY(0)';
            });
        });
        
       
        const currentYear = new Date().getFullYear();
        const copyrightElement = document.querySelector('.footer-bottom p:first-child');
        
        if (copyrightElement) {
            const copyrightText = copyrightElement.textContent;
            copyrightElement.textContent = copyrightText.replace('2025', currentYear);
        }
    });
