document.addEventListener("DOMContentLoaded", () => {
  let currentCatName = '';

  // Configurar filtros
  const setupFilters = () => {
    const filterButton = document.querySelector(".btn-filter");
    const clearFilterButton = document.querySelector(".btn-clear-filter");
    const catCards = document.querySelectorAll(".cat-card");

    if (filterButton) {
      filterButton.addEventListener("click", () => {
        const selectedIdades = getSelectedFilters("idade");
        const selectedSexos = getSelectedFilters("sexo");
        const selectedCores = getSelectedFilters("cor");
        const selectedSaude = getSelectedFilters("saude");

        const anyFilterSelected =
          selectedIdades.length > 0 || selectedSexos.length > 0 || selectedCores.length > 0 || selectedSaude.length > 0;

        if (!anyFilterSelected) {
          showNotification("Nenhum filtro selecionado!", "warning");
          return;
        }

        catCards.forEach((card) => {
          const idade = card.getAttribute("data-idade");
          const sexo = card.getAttribute("data-sexo");
          const cor = card.getAttribute("data-cor");
          const saude = card.getAttribute("data-saude");

          const matchesIdade = selectedIdades.length === 0 || selectedIdades.includes(idade);
          const matchesSexo = selectedSexos.length === 0 || selectedSexos.includes(sexo);
          const matchesCor = selectedCores.length === 0 || selectedCores.includes(cor);
          const matchesSaude =
            selectedSaude.length === 0 || selectedSaude.every((item) => saude && saude.includes(item));

          if (matchesIdade && matchesSexo && matchesCor && matchesSaude) {
            card.classList.remove("hidden");
          } else {
            card.classList.add("hidden");
          }
        });

        updateCatCounter();
      });
    }

    if (clearFilterButton) {
      clearFilterButton.addEventListener("click", () => {
        document.querySelectorAll('.filter-option input[type="checkbox"]').forEach((checkbox) => {
          checkbox.checked = false;
        });

        catCards.forEach((card) => {
          card.classList.remove("hidden");
        });

        updateCatCounter();
      });
    }
  };

  const getSelectedFilters = (name) => {
    const checkboxes = document.querySelectorAll(`.filter-option input[name="${name}"]:checked`);
    return Array.from(checkboxes).map((checkbox) => checkbox.value);
  };

  const updateCatCounter = () => {
    const visibleCats = document.querySelectorAll(".cat-card:not(.hidden)").length;
    const pageTitle = document.querySelector(".page-title");

    if (pageTitle) {
      pageTitle.textContent = `${visibleCats} Gatinhos Encontrados`;
    }
  };

  // Configurar modal de adoção
  const setupAdoptionModal = () => {
    const modalOverlay = document.getElementById('modalOverlay');
    const modalClose = document.getElementById('modalClose');
    const cancelBtn = document.getElementById('cancelBtn');
    const adoptionForm = document.getElementById('adoptionForm');
    const phoneInput = document.getElementById('adopterPhone');

    // Abrir modal ao clicar em qualquer botão "Me adote"
    document.addEventListener('click', (e) => {
      if (e.target.classList.contains('btn-adopt')) {
        currentCatName = e.target.getAttribute('data-cat-name') || 'este gatinho';
        openModal();
      }
    });

    // Fechar modal
    const closeModal = () => {
      modalOverlay.classList.remove('active');
      document.body.style.overflow = 'auto';
      adoptionForm.reset();
    };

    const openModal = () => {
      modalOverlay.classList.add('active');
      document.body.style.overflow = 'hidden';
    };

    modalClose.addEventListener('click', closeModal);
    cancelBtn.addEventListener('click', closeModal);

    // Fechar modal ao clicar no overlay
    modalOverlay.addEventListener('click', (e) => {
      if (e.target === modalOverlay) {
        closeModal();
      }
    });

    // Fechar modal com ESC
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && modalOverlay.classList.contains('active')) {
        closeModal();
      }
    });

    // Máscara para telefone
    phoneInput.addEventListener('input', (e) => {
      let value = e.target.value.replace(/\D/g, '');
      
      if (value.length > 0) {
        if (value.length <= 2) {
          value = `(${value}`;
        } else if (value.length <= 7) {
          value = `(${value.substring(0, 2)}) ${value.substring(2)}`;
        } else if (value.length <= 11) {
          value = `(${value.substring(0, 2)}) ${value.substring(2, 7)}-${value.substring(7)}`;
        } else {
          value = `(${value.substring(0, 2)}) ${value.substring(2, 7)}-${value.substring(7, 11)}`;
        }
      }
      
      e.target.value = value;
    });

    // Envio do formulário
    adoptionForm.addEventListener('submit', (e) => {
      e.preventDefault();
      
      const formData = {
        nome: document.getElementById('adopterName').value.trim(),
        email: document.getElementById('adopterEmail').value.trim(),
        telefone: phoneInput.value.trim(),
        mensagem: document.getElementById('adopterMessage').value.trim(),
        gato: currentCatName
      };

      // Validações
      if (!formData.nome) {
        showNotification('Por favor, informe seu nome completo.', 'error');
        return;
      }

      if (!formData.email || !isValidEmail(formData.email)) {
        showNotification('Por favor, informe um email válido.', 'error');
        return;
      }

      if (!formData.telefone || formData.telefone.length < 14) {
        showNotification('Por favor, informe um telefone válido.', 'error');
        return;
      }

      // Simular envio
      const submitBtn = document.querySelector('.btn-submit');
      const originalText = submitBtn.textContent;
      
      submitBtn.innerHTML = 'Enviando...';
      submitBtn.disabled = true;

      setTimeout(() => {
        showNotification(`Solicitação de adoção para ${currentCatName} enviada com sucesso! Entraremos em contato em breve.`, 'success');
        closeModal();
        
        submitBtn.innerHTML = originalText;
        submitBtn.disabled = false;
        
        // Aqui você enviaria os dados para o servidor
        console.log('Dados da adoção:', formData);
      }, 2000);
    });
  };

  // Função para validar email
  const isValidEmail = (email) => {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
  };

  // Função para mostrar notificações
  const showNotification = (message, type = 'info') => {
    // Remover notificação existente
    const existingNotification = document.querySelector('.notification');
    if (existingNotification) {
      existingNotification.remove();
    }

    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.textContent = message;
    
    // Estilos da notificação
    notification.style.cssText = `
      position: fixed;
      top: 20px;
      right: 20px;
      padding: 15px 20px;
      border-radius: 8px;
      color: white;
      font-weight: 500;
      z-index: 10000;
      transform: translateX(100%);
      transition: transform 0.3s ease;
      max-width: 350px;
      word-wrap: break-word;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
    `;
    
    if (type === 'success') {
      notification.style.backgroundColor = '#4CAF50';
    } else if (type === 'error') {
      notification.style.backgroundColor = '#f44336';
    } else if (type === 'warning') {
      notification.style.backgroundColor = '#ff9800';
    } else {
      notification.style.backgroundColor = '#2196F3';
    }
    
    document.body.appendChild(notification);
    
    // Animar entrada
    setTimeout(() => {
      notification.style.transform = 'translateX(0)';
    }, 100);
    
    // Remover após 5 segundos
    setTimeout(() => {
      notification.style.transform = 'translateX(100%)';
      setTimeout(() => {
        if (notification.parentNode) {
          notification.parentNode.removeChild(notification);
        }
      }, 300);
    }, 5000);
  };

  // Inicializar todas as funcionalidades
  setupFilters();
  setupAdoptionModal();
});